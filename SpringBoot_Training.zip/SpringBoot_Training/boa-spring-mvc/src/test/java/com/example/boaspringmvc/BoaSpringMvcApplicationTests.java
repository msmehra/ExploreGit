package com.example.boaspringmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaSpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
