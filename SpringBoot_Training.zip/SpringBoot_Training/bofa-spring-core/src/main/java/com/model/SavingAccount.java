package com.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("sa")
public class SavingAccount implements InterestCalculator{
	@Value(value="6")
	private int duration;
	
	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	public double getRoi() {
		return roi;
	}


	public void setRoi(double roi) {
		this.roi = roi;
	}


	@Value(value="6.5")
	private double roi;
	

	@Override
	public double calculate(double amount) {
		// TODO Auto-generated method stub
		return (int) (amount*roi/duration);
	}
}
