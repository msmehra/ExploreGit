package com.example.bofaspringcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BofaSpringCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BofaSpringCoreApplication.class, args);
	}

}
