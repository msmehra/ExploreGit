package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.User;
import com.service.UserService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/mainapp")
public class AppController {

	
	
	@Autowired
	private UserService service;

	@PostMapping("/login")
	public String loginVALID(@ModelAttribute User user) {

		if (service.loginValid(user)) {
			return "Login Success";
		}

		return "login Failed";
	}

	@PostMapping("/register")
	public String registerUser(@RequestBody User user) {

		 

		service.addUser(user);

		return "user added";
	}
	@GetMapping("/loadall")
	@ApiOperation(value = "Load all the records", notes = "laod User Details",response = User.class)
	public List<User> loadUser(){
		return service.loadUsers();
	}
	@GetMapping("/finduser/{name}")
	public String findUser(@PathVariable String name) {
		if(service.findUser(name)) {
			return name +" user found";
		}
		return "user not available";
	}
	
	@DeleteMapping("/deleteuser/{name}")
	public void deleteUser(@PathVariable String name) {
		service.deleteUser(name);
			//return name +"user found and deleted";
		
		//return "user not available";
	}
	@PutMapping("/updateuser/{uname}")
	public void updateUser(@PathVariable("uname")String uname,@RequestBody User usrObj){
		service.updateUser(usrObj.getEmail(), uname);
		//return "";
	}
	{
		
	}
	

}
