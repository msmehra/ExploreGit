package com.delegate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AppDelegate {

	@Autowired
	RestTemplate template;
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
			
	public String loadEmp(String pname) {
			String response = template.exchange("http://emp-service/loademp/{pname}", HttpMethod.GET,
					null,
					new ParameterizedTypeReference<String>() {
					},pname).getBody();		
			return response;
	}
	
	public String loadShuttle(String city) {
		String response = template.exchange("http://shuttle-service/loadshuttle/{city}", HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				},city).getBody();		
		return response;
}

	
}
