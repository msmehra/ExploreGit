package com.dao;

import org.springframework.stereotype.Repository;

import com.model.Employee;
import com.model.Employees;

@Repository
public class EmployeeDAO {
	
	private static Employees list = new Employees();
	
	static{
		list.getEmpList().add(new Employee("admin",1,"admin@admin.com"));
		list.getEmpList().add(new Employee("manager",2,"manager@admin.com"));
		list.getEmpList().add(new Employee("contractor",3,"contractor@admin.com"));
	}
	
	public Employees getEmployees() {
		return list;
	}
	
	public void addEmployee(Employee employee) {
		list.getEmpList().add(employee);
	}
	

}
