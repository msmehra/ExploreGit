package com.java.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.ComponentScan; 

@SpringBootApplication
@ComponentScan("com")
@EnableCircuitBreaker
//@EnableSwagger2
public class SpringBootDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootDemoApplication.class, args);
    }
    
	/*
	 * @Bean public Docket swaggerConfig() { return new
	 * Docket(DocumentationType.SWAGGER_2) .select()
	 * .apis(RequestHandlerSelectors.basePackage("com")) .build()
	 * .apiInfo(apiDetails()); }
	 * 
	 * public ApiInfo apiDetails() { return new ApiInfo("Bank of America",
	 * "Sample App to access the URLs", "2.0", "Free for Internal Use", new
	 * springfox.documentation.service.Contact("Manoj", "http://wwww.yahoo.com",
	 * "manoj@mail.com"), "API Licence", "http://www.boa.com",
	 * Collections.emptyList()); }
	 */
}
