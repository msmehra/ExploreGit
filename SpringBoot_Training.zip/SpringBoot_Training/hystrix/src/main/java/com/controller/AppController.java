package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.delegate.AppDelegate;

@RestController
public class AppController {
	
	@Autowired
	private AppDelegate appDelegate;
	
	@GetMapping("/loademp")
	//@ApiOperation(value = "Load all the records", notes = "laod User Details",response = Employee.class)
	public String loadEmp() {
		return appDelegate.loadEmp();
	}
	
	/*
	 * @PostMapping("/adduser")
	 * 
	 * @ApiOperation(value = "Add the Employee to the system", notes =
	 * "Add employee to the System",response = Employee.class) public
	 * ResponseEntity<Object> addUser(@ApiParam(value =
	 * "Details of the employee to be added in JSON object",required =
	 * true) @RequestBody Employee emp){ int i
	 * =dao.getEmployees().getEmpList().size() + 1;
	 * 
	 * emp.setId(i); dao.addEmployee(emp); return ResponseEntity.ok("User added"); }
	 */
	
	

}
