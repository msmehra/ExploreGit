package com.delegate;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class AppDelegate {

	RestTemplate template = new RestTemplate();
			
	@HystrixCommand(fallbackMethod = "callOnFailorDelayed",
			commandProperties = {
					@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="2000")
			}//,ignoreExceptions = {CustomException.class}
	)
	public String loadEmp() {
			String response = template.exchange("http://localhost:8090/loademp", HttpMethod.GET,
					null,
					new ParameterizedTypeReference<String>() {
					}).getBody();		
			return response;
	}

	
	public String callOnFailorDelayed() {
		return "oops....something went wrong, please try sometime";
	}
	
}
