package com.example.boamsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaMsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
