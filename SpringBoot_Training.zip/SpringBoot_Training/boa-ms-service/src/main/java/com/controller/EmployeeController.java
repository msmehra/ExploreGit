package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Employee;

@RestController
public class EmployeeController {
	
	private static Map<String, List<Employee>> empdb= new HashMap<String, List<Employee>>();
	//private static Map<String, List<Employee>> empdb;
	
	static {
		empdb= new HashMap<String, List<Employee>>();
		
		List<Employee> lst= new ArrayList<Employee>();
		Employee emp= new Employee("sudeep", "sudeep@mail.com","mumbai");
		lst.add(emp);
		
		emp= new Employee("suresh", "suresh@mail.com", "madurai");
		lst.add(emp);
		empdb.put("banking", lst);
		lst= new ArrayList<Employee>();
		emp= new Employee("rekha", "rekha@mail.com", "chennai");
		lst.add(emp);
		emp= new Employee("manisha", "manisha@mail.com", "hyderabad");
		lst.add(emp);
		empdb.put("healthcare", lst);
	}
	@GetMapping("/loademp/{proname}")
	public List<Employee> loadEmployee(@PathVariable String proname){
		
		List<Employee> emplist= empdb.get(proname);
		if(emplist ==null) {
			emplist= new ArrayList<Employee>();
			Employee e= new Employee("NA", "NA", "Not Found");
			emplist.add(e);
		}
		return emplist;
	}
	
	@GetMapping("/loadsingle")
	public Employee getData() {
		
		Employee emp = new Employee("Manoj", "Fbd", "greater");
		return emp;
	}
}
